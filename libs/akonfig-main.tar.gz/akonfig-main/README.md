## Использование библиотеки

```python
from ConfigMerger import ConfigMerger

merger = ConfigMerger() # base_dir должен быть с / в конце

config = merger.get_config(module_name="config") # -> результатом будет слияние config/config.local.py в config/config.py
config2 = merger.get_config(module_name="config2", 
                            modules="module") # -> результатом будет слияние config/module/config2.local.py в config/module/config2.py
# modules должно быть без / в конце


```


## Создание конфигов

Конфиги построены на BaseModel из Pydantic.

Файл с конфигом должен иметь объект настроек в переменной settings

Пример config.py:

```python
from pydantic import BaseModel


class MyConfig(BaseModel):
    user: str = 'user'
    password: str = 'password'


settings = MyConfig()
```

## Поведение при слиянии

Всё, что унаследованно от BaseModel будет заменяться по полям(До вложенности 3, 
дальше заменяется, допустимая глубина вложенности изменяется при инициализации ConfigMerger).

Все поля, что присутствуют в **stage** конфиге будут наложены на дефолтный.

При этом работу слияния полей можно изменить, для этого нужно в **stage** конфиге использовать классы, которые унаследованные от Mergeable. В библиотеке уже есть некоторые классы, которые можно использовать из коробки.

Пример config.py(default):

```python
from pydantic import BaseModel


class MyConfig(BaseModel):
    user: str = 'user'
    password: str = 'password'
    numbers: list = [1, 2, 3]


settings = MyConfig()
```

Пример config.local.py(stage):

```python
from pydantic import BaseModel
from ConfigMerger.classes import ExtendedList


class MyConfig(BaseModel):
    password: str = 'myOwnPassWord'
    numbers: ExtendedList = ExtendedList([4, 5, 6])


settings = MyConfig()
```
В результате при мердже этих двух конфигов получится:
```json
{
  "user": "user", 
  "password": "myOwnPassWord", 
  "numbers": [1, 2, 3, 4, 5, 6]
}
```

Значение поля **user** осталось нетронутым из-за того, что оно отсутствовало в **stage** конфиге

Значение поля **password** заменилось потому-что, присутствовало в **stage** конфиге и не было унаследовано от Mergeable или BaseModel

Значение поля **numbers** изменилось дополнившись значениями из **stage** конфига потому-что в **stage** конфиге был использован класс, унаследованный от Mergeable, а именно ExtendedList, который дополняет список default конфига