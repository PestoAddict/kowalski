from ConfigMerger import ConfigMerger
from .config import config_expected as test_simple_expected
from .config.deep import config_expected as test_deep_expected
from .config.mergable import config_expected as test_mergable_expected
from .config.module1 import config_expected as test_simple_module_depth_1_expected
from .config.module1.module2 import config_expected as test_simple_module_depth_2_expected
from .config.none_ import config_expected as test_simple_none_expected


def test_simple():
    merger = ConfigMerger()
    result = merger.get_config('config')

    assert test_simple_expected.settings.json() == result.json()


def test_simple_none_():
    merger = ConfigMerger()
    result = merger.get_config('config', modules='none_')

    assert test_simple_none_expected.settings.json() == result.json()


def test_simple_module_depth_1():
    merger = ConfigMerger()
    result = merger.get_config('config', modules='module1')

    assert test_simple_module_depth_1_expected.settings.json() == result.json()


def test_simple_module_depth_2():
    merger = ConfigMerger()
    result = merger.get_config('config', modules='module1/module2')

    assert test_simple_module_depth_2_expected.settings.json() == result.json()


def test_mergeable():
    merger = ConfigMerger()
    result = merger.get_config('config', modules='mergable')

    assert test_mergable_expected.settings.json() == result.json()


def test_deep():
    merger = ConfigMerger(merge_deep=1)
    result = merger.get_config('config', modules='deep')

    assert test_deep_expected.settings.json() == result.json()
