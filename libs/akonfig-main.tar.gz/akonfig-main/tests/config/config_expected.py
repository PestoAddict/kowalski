from pydantic import BaseModel


class MyConfig(BaseModel):
    user: str = 'user'
    password: str = 'myOwnPassWord'


settings = MyConfig()
