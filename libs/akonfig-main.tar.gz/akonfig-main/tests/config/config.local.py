from pydantic import BaseModel


class MyConfig(BaseModel):
    password: str = 'myOwnPassWord'


settings = MyConfig()
