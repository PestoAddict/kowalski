from pydantic import BaseModel

from ConfigMerger.classes import ExtendedList


class House(BaseModel):
    name: str = 'NewHouse'


class Street(BaseModel):
    name: str = 'NewStreet'
    houses: ExtendedList[House] = [House(), House()]

    class Config:
        arbitrary_types_allowed = True


class City(BaseModel):
    name: str = 'NewCity'
    streets: list[Street] = [Street()]


class State(BaseModel):
    name: str = 'NewState'
    cities: list[City] = [City()]


class Country(BaseModel):
    name: str = 'NewCountry'
    states: list[State] = [State()]


class MyConfig(BaseModel):
    countries: list[Country] = [Country()]


settings = MyConfig()
