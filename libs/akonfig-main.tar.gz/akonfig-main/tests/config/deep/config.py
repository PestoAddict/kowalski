from pydantic import BaseModel


class House(BaseModel):
    name: str = 'House'


class Street(BaseModel):
    name: str = 'Street'
    houses: list[House] = [House()]


class City(BaseModel):
    name: str = 'City'
    streets: list[Street] = [Street()]


class State(BaseModel):
    name: str = 'State'
    cities: list[City] = [City()]


class Country(BaseModel):
    name: str = 'Country'
    states: list[State] = [State()]


class MyConfig(BaseModel):
    countries: list[Country] = [Country()]
    name: str = 'Config'


settings = MyConfig()
