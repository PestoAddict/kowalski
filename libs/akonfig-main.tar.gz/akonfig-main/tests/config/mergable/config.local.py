from pydantic import BaseModel

from ConfigMerger.classes import ExtendedList


class MyConfig(BaseModel):
    password: str = 'myOwnPassWord'
    numbers: ExtendedList = ExtendedList([4, 5, 6])

    class Config:
        arbitrary_types_allowed = True


settings = MyConfig()
