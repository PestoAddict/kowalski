from pydantic import BaseModel


class MyConfig(BaseModel):
    user: str = 'user'
    password: str = 'myOwnPassWord'
    numbers: list = [1, 2, 3, 4, 5, 6]


settings = MyConfig()
