from pydantic import BaseModel


class MyConfig(BaseModel):
    user: str = 'user'
    password: str = 'password'
    numbers: list = [1, 2, 3]


settings = MyConfig()
