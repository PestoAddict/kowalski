from pydantic import BaseModel


class MyConfig(BaseModel):
    user: str = 'user'
    password: str = 'password'


settings = MyConfig()
