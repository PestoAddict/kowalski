"""
Config Merger package
"""
from setuptools import setup, find_packages
PACKAGE = "ConfigMerger"
NAME = "ConfigMerger"
DESCRIPTION = 'Config merger base on Pydantic configs'
AUTHOR = 'Ostap Kormiltsev'
AUTHOR_EMAIL = "o.kormiltsev@appcntr.ru"
URL = "https://github.com"
VERSION = '0.1.3.1'

setup(
    name=NAME,
    version=VERSION,
    description=DESCRIPTION,
    author=AUTHOR,
    author_email=AUTHOR_EMAIL,
    license="BSD",
    url=URL,
    packages=find_packages(include=['ConfigMerger']),
    install_requires=['pydantic>=1.9.0'],
    setup_requires=['pydantic>=1.9.0'],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Web Environment",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: BSD License",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
    ],
    zip_safe=False,
)
