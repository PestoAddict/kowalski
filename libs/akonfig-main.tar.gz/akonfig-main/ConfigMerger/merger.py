import importlib.util as imp_ut
from functools import lru_cache
from typing import Optional, TypeVar

from pydantic import BaseModel

from .classes import Mergeable

Settings = TypeVar('Settings')


class ConfigMerger:
    def __init__(
            self,
            merge_deep: int = 3,
            base_dir: str = './',
    ):
        self._merge_deep = merge_deep
        self._base_dir = base_dir

    def _recursive_merge(self, to_: BaseModel, from_: BaseModel, deep=0):
        if deep > self._merge_deep:
            return from_
        for field in from_.__fields__:
            from_field = getattr(from_, field)
            to_field = getattr(to_, field)

            # Установка значения, если поле унаследовано от специального класса.
            if isinstance(from_field, Mergeable):
                setattr(
                    to_,
                    field,
                    from_field.handle_merge(to_=to_field, from_=from_field),
                )
                continue

            # Рекурсивная установка полей в вложенных моделях.
            if isinstance(from_field, BaseModel):
                setattr(
                    to_,
                    field,
                    self._recursive_merge(to_field, from_field, deep=deep + 1),
                )
                continue

            # Замена значения из to_ на значение из from_
            setattr(
                to_,
                field,
                from_field,
            )
        return to_

    def _import_module(self, path: str):
        try:
            spec = imp_ut.spec_from_file_location(
                name="_".join(path.split('/')),
                location=path,
            )
            module = imp_ut.module_from_spec(spec)
            spec.loader.exec_module(module)
            return module
        except FileNotFoundError:
            return None

    def merge_configs(
            self,
            to_path: str = 'config.py',
            from_path: str = 'config.local.py',
    ) -> Settings:
        to_: BaseModel = getattr(
            self._import_module(path=f"{self._base_dir}{to_path}"),
            'settings',
        )
        from_module = self._import_module(path=f"{self._base_dir}{from_path}")
        if from_module is None:
            return to_
        from_: BaseModel = getattr(
            from_module,
            'settings',
        )
        return self._recursive_merge(to_=to_, from_=from_)

    def get_config_without_cache(
            self,
            module_name: str,
            modules: str = '',
    ):
        base_path = f'/config/{modules}/{module_name}'
        return self.merge_configs(
            to_path=f'{base_path}.py',
            from_path=f'{base_path}.local.py',
        )

    @lru_cache()
    def get_config(
            self,
            module_name: str,
            modules: str = '',
    ):
        return self.get_config_without_cache(
            module_name=module_name,
            modules=modules,
        )
