from collections import abc
from typing import Any, Iterable

from .exceptions import NotCompatibleError


class Mergeable:
    """Class with it own behavior on merge"""

    def handle_merge(self, to_: Any, from_: Any):
        raise NotImplementedError


class ExtendedList(list, Mergeable):
    """Class to extend target list on merge.
    Can handle any type of iterable on target but result will be list"""

    def handle_merge(self, to_: Iterable, from_: Iterable):
        if not isinstance(to_, abc.Iterable):
            raise NotCompatibleError(f"Expected any iterable object but passed {to_.__class__}")
        return [*to_, *from_]


class UnionDict(dict, Mergeable):
    """Class to merge dicts using | operator"""

    def handle_merge(self, to_: dict, from_: dict):
        if not isinstance(to_, dict):
            raise NotCompatibleError(f"Expected dict object but passed {to_.__class__}")
        return to_ | from_
