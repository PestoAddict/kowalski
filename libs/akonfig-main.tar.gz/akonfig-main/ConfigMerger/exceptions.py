class MergeConflictError(Exception):
    """Base module exception"""


class NotCompatibleError(MergeConflictError):
    """Raised when merging class can't handle passed type"""
