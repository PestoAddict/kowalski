# /usr/bin/python
# -*- coding: utf-8 -*-
"""
Initial module
"""
from .__version__ import __version__
from .merger import ConfigMerger
