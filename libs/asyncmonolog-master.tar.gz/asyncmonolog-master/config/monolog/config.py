from monolog.config import MonologConfig, Connection, Node


class Settings(MonologConfig):
    connection: Connection = Connection(
        serv="localhost",
        port=27017,
        username="test",
        auth_source="admin",
        auth_mechanism="SCRAM-SHA-1",
        password="test",
        database="pyservices",
    )
    node: Node = Node(
        host="myService",
        ip="127.0.0.1",
    )
    current_level: str = "debug"


settings = Settings()
