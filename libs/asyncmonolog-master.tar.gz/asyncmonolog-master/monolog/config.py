from pydantic import BaseModel


class Node(BaseModel):
    host: str
    ip: str


class Connection(BaseModel):
    serv: str
    port: int
    username: str
    auth_source: str
    auth_mechanism: str
    password: str
    database: str


class MonologConfig(BaseModel):
    connection: Connection
    app_name: str = "unknown"
    current_level: str
    mongo_logger_duplicate: bool = True
    std_logger_duplicate: bool = True
    std_logger_handlers: list = ["cls", 'fh']
    node: Node
