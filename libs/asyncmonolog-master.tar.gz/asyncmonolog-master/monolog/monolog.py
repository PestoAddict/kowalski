# /usr/bin/python
# -*- coding: utf-8 -*-
"""
MongoDB logger module
"""
import datetime
import inspect
import json
import logging
import os
import random
import sys
from logging.handlers import RotatingFileHandler
from typing import Optional, Union
try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal  # Python 3.7 compatibility

from ConfigMerger import ConfigMerger
import aiohttp
from motor.motor_asyncio import AsyncIOMotorClient

from .config import MonologConfig

_std_logger: Optional[logging.Logger] = None
shared_connection: Optional[dict] = None


class MongoLogger:
    """
    MongoDB logger class.\n
    """
    LEVELS = {'critical': 50, 'error': 40, 'warning': 30, 'info': 20, 'debug': 10}
    HERALD_URL = "https://herald.crpo.su"

    def _generate_pid(self):
        self._pid = f"{random.randrange(1000, 9999)}_{datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')}"

    def set_pid(self, pid):
        self._pid = pid

    def get_pid(self):
        return self._pid

    def __init__(
            self,
            collection_name='default_logger',
            pid='',
            config: MonologConfig = None,
    ):
        _current_dir = os.getcwd()
        if os.path.exists('version'):
            self._version = open('version').read()
        else:
            self._version = 'unknown'

        self._pid = pid
        if self._pid == '':
            self._generate_pid()

        if config:
            self.config: MonologConfig = config
        else:
            self.config: MonologConfig = ConfigMerger().get_config('config', 'monolog')

        self._app_name = self.config.app_name
        self._current_level = self.config.current_level
        self._collection = collection_name.replace(".", "_")
        self._std_logger_duplicate = self.config.std_logger_duplicate
        self._mongo_logger_duplicate = self.config.mongo_logger_duplicate

        global shared_connection
        if shared_connection is None:
            self._mongo_cli = AsyncIOMotorClient(
                self.config.connection.serv,
                self.config.connection.port,
                username=self.config.connection.username,
                password=self.config.connection.password,
                authSource=self.config.connection.auth_source,
                authMechanism=self.config.connection.auth_mechanism,
            )

            self._db = self._mongo_cli[self.config.connection.database]
            self._node = self.config.node.dict()
            shared_connection = {
                "mongo_cli": self._mongo_cli,
                "db": self._db,
                "node": self._node,
            }
        else:
            self._mongo_cli = shared_connection["mongo_cli"]
            self._db = shared_connection["db"]
            self._node = shared_connection["node"]

        try:
            self._build_std_logger()
        except Exception as ex_error:
            print(f"MongoLogger error. ex_error: {ex_error}.")
            global _std_logger
            _std_logger = None
            self._std_logger_duplicate = False

    def _build_std_logger(self):
        global _std_logger
        if _std_logger:
            return _std_logger
        _std_logger = logging.getLogger('default')
        _log_format = "[%(levelname)-8s][%(asctime)s][%(module)-10s]%(message)s"
        _std_logger.setLevel(self.LEVELS[self._current_level])
        handlers_config = self.config.std_logger_handlers
        if "fh" in handlers_config:
            _std_logger.addHandler(self._get_file_handler(_log_format))
        if 'cls' in handlers_config:
            _std_logger.addHandler(self._get_stream_handler(_log_format))
        return _std_logger

    def _get_file_handler(self, _log_format):
        _current_dir = os.getcwd()
        logs_path = os.path.join(_current_dir, 'logs')
        if not os.path.exists(logs_path):
            os.mkdir(logs_path)
        file_name = os.path.join(logs_path, f"{self._collection}.log")
        file_handler = RotatingFileHandler(file_name, maxBytes=1024 * 1024 * 300, backupCount=4)
        file_handler.setFormatter(logging.Formatter(_log_format))
        return file_handler

    def _get_stream_handler(self, _log_format):
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(logging.Formatter(_log_format))
        return stream_handler

    async def _emit(self, level: str, msg: str, data: dict):
        """
        Emit log message
        :param level: message level
        :param msg: critical message
        :param data: dump dict
        :return: None
        """
        current_frame = inspect.currentframe()
        emit_func = current_frame.f_back.f_back.f_code.co_name

        if self._std_logger_duplicate:
            self._emit_std_logger(emit_func, level, msg, data)
        if self._mongo_logger_duplicate:
            await self._emit_mongo(emit_func, level, msg, data)

    def _emit_std_logger(self, emit_func: str, level: str, msg: str, data: dict):
        global _std_logger
        try:
            if data:
                _std_logger.log(self.LEVELS[level], "[%s][%s] %s %s.", emit_func, self._pid, msg, data)
            else:
                _std_logger.log(self.LEVELS[level], "[%s][%s] %s.", emit_func, self._pid, msg)
        except Exception as ex:
            print("[CRITICAL][%s][%s] %s.", emit_func, self._pid, msg)

    async def _emit_mongo(self, emit_func: str, level: str, msg: str, data: dict):
        try:
            if self.LEVELS[level] < self.LEVELS[self.config.current_level]:
                return
            dt = datetime.datetime.now()
            current_collection = f"{self._collection}_{dt.strftime('%Y%m')}"
            collection = self._db[current_collection]
            current_trace = [str(f) for f in inspect.trace()]
            if isinstance(data, dict):
                data["function"] = emit_func
                if self.LEVELS[level] <= self.LEVELS['error']:
                    data["trace"] = current_trace
            else:
                data += f"function={emit_func}"
                if self.LEVELS[level] <= self.LEVELS['error']:
                    data += f"trace={current_trace}"
            var = {
                "created": datetime.datetime.utcnow(),
                "node": self._node,
                "pid": self._pid,
                "raddr": "x.x.x.x",
                "level": level,
                "msg": msg,
                "dump": data,
                "appName": self._app_name,
                "appVersion": self._version
            }
            await collection.insert_one(var)
        except Exception as ex_error:
            global _std_logger
            if _std_logger:
                _std_logger.critical("MongoLogger Critical error. %s dump: [%s][%s] %s %s.",
                                     ex_error, level, self._pid, msg, data)
            else:
                print("MongoLogger Critical error. %s dump: [%s][%s] %s %s.",
                      ex_error, level, self._pid, msg, data)

    async def _fill_traceback_info(self, data):
        exc_type, exc_obj, exc_tb = sys.exc_info()
        traceback = list(map(lambda x: {"function": x.function, "lineno": x.lineno}, inspect.stack()[1:]))
        data["traceback"] = traceback

        if exc_tb:
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            data['module'] = fname
            data['type'] = str(exc_type)
            data['error_line'] = exc_tb.tb_lineno
        return data

    async def critical(self, msg: str, data=None) -> None:
        """
        Critical message.
        :param msg: critical message
        :param data: dump dict
        :return: None
        """
        if data is None:
            data = {}
        await self._fill_traceback_info(data)
        await self._emit('critical', msg, data)

    async def error(self, msg: str, data=None) -> None:
        """
        Error message.
        :param msg: error message
        :param data: dump dict
        :return: None
        """
        if data is None:
            data = {}
        await self._fill_traceback_info(data)
        await self._emit('error', msg, data)

    async def warning(self, msg: str, data=None) -> None:
        """
        Warning message.
        :param msg: warning message
        :param data: dump dict
        :return: None
        """
        if data is None:
            data = {}
        await self._emit('warning', msg, data)

    async def info(self, msg: str, data=None) -> None:
        """
        Info message.
        :param msg: info message
        :param data: dump dict
        :return: None
        """
        if data is None:
            data = {}
        await self._emit('info', msg, data)

    async def debug(self, msg: str, data=None) -> None:
        """
        Debug message.
        :param msg: debug message
        :param data: dump dict
        :return: None
        """
        if data is None:
            data = {}
        await self._emit('debug', msg, data)

    async def send_notify(
            self,
            text: str,
            destination: Union[str, int],
            service: Literal["rocket_chat", "telegram"] = "rocket_chat",
            title: Optional[str] = None,
            author: Optional[str] = "monolog",
    ) -> None:
        """
        Отправка уведомления через herald

        :param text: Текст сообщения
        :param destination: Название канала/ник пользователя (включая '@') для RocketChat; ID чата/группы для Telegram
        :param service: Название сервиса. Возможные значения: 'telegram', 'rocket_chat'
        :param title: Тема сообщения (По умолчанию название приложения)
        :param author: Автор сообщения (По умолчанию 'monolog')
        """
        if not title:
            title = self._app_name

        raw_data = {
            "service": service,
            "text": text,
            "destination": destination,
            "title": title,
            "author": author,
        }
        data = json.dumps(raw_data).encode("utf-8")
        headers = {'Content-Type': 'application/json'}
        async with aiohttp.ClientSession(headers=headers) as session:
            url = f"{self.HERALD_URL}/notify_with_text"
            async with session.post(url, data=data) as response:
                if response.status != 200:
                    raise RuntimeError(f"Request failed with code {response.status}: {await response.text()}")
