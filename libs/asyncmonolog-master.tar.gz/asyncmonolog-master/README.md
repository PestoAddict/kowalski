# monolog Python package
## Singletoned MongoDB logger + std logger

### Installation
```sh 
pip install git+ssh://git@gitlab.crpo.su/vgds/monolog.git
```
### Build dist
```python setup.py sdist```

#### Requirements:
* pymongo>=3.10.1
* motor>=3.0.0

#### Using:
```python
async def main():
    logger = MongoLogger()
    msg = "test critical msg"
    dump = {
        "body": "test_body",
        "info": "test_info"
    }
    await logger.critical(msg, dump)
```
Config must be in config directory, previously will be used *monolog.local.json*
#### Config example
```json
{
  "connection": {
    "serv": "mongo01.stage.deac",
    "port": 27017,
    "username": "root",
    "authSource": "admin",
    "authMechanism": "SCRAM-SHA-1",
    "password": "xPChvi4kRdLaRE",
    "dataBase": "logs_apiterm"
  },
  "app_name": "app_name",
  "currentLevel": "debug",
  "mongoLoggerDuplicate": true,
  "stdLoggerDuplicate": true,
  "stdLoggerHandlers": ["cls"],
  "node": {
    "host": "myService",
    "ip": "127.0.0.1"
  }
}
```